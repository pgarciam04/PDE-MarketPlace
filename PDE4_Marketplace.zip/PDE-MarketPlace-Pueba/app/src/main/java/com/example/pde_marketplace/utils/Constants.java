package com.example.pde_marketplace.utils;

public class Constants {
}
